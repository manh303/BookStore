--Using SQL ServerQuery
DROP DATABASE IF EXISTS BookStore;
GO
CREATE DATABASE BookStore;
GO
USE BookStore;
GO


CREATE TABLE Account (
    AccountID INT IDENTITY(1,1) PRIMARY KEY,
    UserName VARCHAR(50) NOT NULL UNIQUE,
    Password VARCHAR(255) NOT NULL,
    Role VARCHAR(20) DEFAULT('Customer'),
    AvatarImage VARCHAR(MAX),
    Address NVARCHAR(MAX),
    Status VARCHAR(20) DEFAULT('Active'),
    CONSTRAINT P_Role CHECK (Role IN ('Customer', 'Employee', 'Admin')),
    CONSTRAINT P_Status CHECK (Status IN ('Active', 'Inactive'))
);

CREATE TABLE Customer (
    CustomerID INT IDENTITY(1,1) PRIMARY KEY,
    AccountID INT FOREIGN KEY REFERENCES Account(AccountID),
);



CREATE TABLE Category (
    CategoryID INT PRIMARY KEY IDENTITY(1,1),
    CategoryName NVARCHAR(MAX) NOT NULL
);

CREATE TABLE Author (
    AuthorID INT PRIMARY KEY IDENTITY(1,1),
    AuthorName NVARCHAR(MAX) NOT NULL,
    AuthorBio NTEXT
);

CREATE TABLE Book (
    BookID INT PRIMARY KEY IDENTITY(1,1),
    Title NVARCHAR(MAX) NOT NULL,
    AuthorID INT NOT NULL,
	Description TEXT,
    Price DECIMAL(10, 2) NOT NULL,
    Quantity INT NOT NULL,
    PublicationDate DATE,
    BookImage VARCHAR(MAX),
    CategoryID INT, 
    Status VARCHAR(20) DEFAULT('Active'),
    CONSTRAINT P_Price CHECK (Price >= 0),
    FOREIGN KEY (CategoryID) REFERENCES Category(CategoryID),
    FOREIGN KEY (AuthorID) REFERENCES Author(AuthorID),
    CONSTRAINT B_Status CHECK (Status IN ('Active', 'Inactive'))
);

CREATE TABLE OrderBook (
    OrderID INT PRIMARY KEY IDENTITY(1,1),
    CustomerID INT,
    OrderDate DATETIME DEFAULT GETDATE(),
    Total DECIMAL(10, 2) NOT NULL,
    Address NVARCHAR(MAX) NOT NULL,
    Status VARCHAR(20) DEFAULT('Pending'),
    FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID),
    CONSTRAINT O_Status CHECK (Status IN ('Pending', 'Delivering', 'Delivered', 'Cancelled'))
);

CREATE TABLE OrderDetail (
    OrderDetailID INT PRIMARY KEY IDENTITY(1,1),
    OrderID INT NOT NULL,
    BookID INT NOT NULL,
    Quantity INT NOT NULL,
    Price DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (OrderID) REFERENCES OrderBook(OrderID),
    FOREIGN KEY (BookID) REFERENCES Book(BookID),
    CONSTRAINT P_Quantity CHECK (Quantity >= 0)
);

CREATE TABLE Feedback (
    FeedbackID INT PRIMARY KEY IDENTITY(1,1),    
    BookID INT NOT NULL,
	Rating INT NOT NULL,
    Comment NVARCHAR(MAX),
    FOREIGN KEY (BookID) REFERENCES Book(BookID),
);









INSERT INTO Account (UserName, Password, Role, AvatarImage, Address, Status)
VALUES ('john_doe', 'password123', 'Customer', 'avatar1.jpg', '123 Main St', 'Active');

INSERT INTO Account (UserName, Password, Role, AvatarImage, Address, Status)
VALUES ('jane_smith', 'password456', 'Customer', 'avatar2.jpg', '456 Elm St', 'Active');

INSERT INTO Account (UserName, , Password, Role, AvatarImage, Address, Status)
VALUES ('mike_johnson', 'password789', 'Customer', 'avatar3.jpg', '789 Oak St', 'Active');




-- Insert data for Customer table
INSERT INTO Customer (AccountID)
VALUES
    (6),
    (7),
    (8),
    (9),
    (10);


INSERT INTO Category (CategoryName)
VALUES ('Fiction'),
       ('Non-Fiction'),
       ('Science Fiction'),
       ('Mystery'),
       ('Romance');


INSERT INTO Author (AuthorName)
VALUES ('Author 1'),
       ('Author 2'),
       ('Author 3'),
       ('Author 4'),
       ('Author 5'),
       ('Author 6'),
       ('Author 7'),
       ('Author 8'),
       ('Author 9'),
       ('Author 10');



INSERT INTO Book (Title, AuthorID, CategoryID, Price, Quantity)
VALUES
    ('Book 1', 1, 1, 10.99, 5),
    ('Book 2', 2, 2, 12.99, 3),
    ('Book 3', 3, 3, 9.99, 7),
    ('Book 4', 4, 4, 14.99, 2),
    ('Book 5', 5, 5, 11.99, 4),
    ('Book 6', 6, 1, 8.99, 6),
    ('Book 7', 7, 2, 13.99, 1),
    ('Book 8', 8, 3, 10.99, 5),
    ('Book 9', 9, 4, 12.99, 3),
    ('Book 10', 10, 5, 9.99, 7),
    ('Book 11', 1, 1, 14.99, 2),
    ('Book 12', 2, 2, 11.99, 4),
    ('Book 13', 3, 3, 8.99, 6),
    ('Book 14', 4, 4, 13.99, 1),
    ('Book 15', 5, 5, 10.99, 5);
