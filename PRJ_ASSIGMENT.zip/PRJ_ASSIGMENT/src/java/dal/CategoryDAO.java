package dal;
import java.util.ArrayList;
import java.util.List;
import model.Category;
public class CategoryDAO extends MyDAO{
    public List<Category> getCategorys() {
    List<Category> t = new ArrayList<>();
    xSql = "select * from Category";
    int xCategoryId;
    String xCategoryName;
    
    Category x;
    try {
      ps = con.prepareStatement(xSql);
      rs = ps.executeQuery();
      while(rs.next()) {
        xCategoryId = rs.getInt("CategoryId");  
        xCategoryName = rs.getString("CategoryName");  
        x = new Category(xCategoryId, xCategoryName);
        t.add(x);
      }
      rs.close();
      ps.close();
     }
     catch(Exception e) {
        e.printStackTrace();
     }
    return(t);
  }
    
    public void insert(Category x) {
     xSql = "insert into Category (categoryName) values (?)"; 
     try {
      ps = con.prepareStatement(xSql);
      ps.setString(1, x.getCategoryName());
      ps.executeUpdate();
      ps.close();
     }     
     catch(Exception e) {
        e.printStackTrace();
     }
  }
    public void delete(String categoryId) {
     xSql = "delete from Category where categoryId=?";
     try {
        ps = con.prepareStatement(xSql);
        ps.setString(1, categoryId);
        ps.executeUpdate();
        //con.commit();
        ps.close();
     }
     catch(Exception e) {
        e.printStackTrace();
     }
  }
    
    public void update(String xRollno, Category x) {
     xSql = "update Student set Category where CategoryId=?";
     try {      
        ps = con.prepareStatement(xSql);
        ps.setString(1, x.getCategoryName());
        ps.executeUpdate();
        ps.close();
     }
      catch(Exception e) {
        e.printStackTrace();
      }
  }
    
    
}
