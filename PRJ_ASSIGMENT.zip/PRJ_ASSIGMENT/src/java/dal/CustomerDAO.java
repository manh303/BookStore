package dal;

import java.util.ArrayList;
import java.util.List;
import model.Customer;

public class CustomerDAO extends MyDAO {

    public List<Customer> getCustomers() {
        List<Customer> t = new ArrayList<>();
        xSql = "select * from Customer";

        int xCustomerId;
        int xAccountId;
        Customer x;
        try {
            ps = con.prepareStatement(xSql);
            rs = ps.executeQuery();
            while (rs.next()) {
                xCustomerId = rs.getInt("CustomerId");
                xAccountId = rs.getInt("AccountId");
                x = new Customer(xCustomerId, xAccountId);
                t.add(x);
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return (t);
    }
}
