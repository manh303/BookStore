package dal;

import java.util.ArrayList;
import java.util.List;
import model.Book;

public class BookDAO extends MyDAO {

    public List<Book> getBooks() {
        List<Book> t = new ArrayList<>();
        xSql = "select * from Book";
        int xBookId;
        String xTitle;
        int xAuthorId;
        String xDescription;
        double xPrice;
        int xQuantity;
        String xPublicationDate;
        String xBookImg;
        String xStatus;
        Book x;
        try {
            ps = con.prepareStatement(xSql);
            rs = ps.executeQuery();
            while (rs.next()) {
                xBookId = rs.getInt("BookID");
                xTitle = rs.getString("Title");
                xAuthorId = rs.getInt("AuthorID");
                xDescription = rs.getString("Description");
                xPrice = rs.getDouble("Price");
                xQuantity = rs.getInt("Quantity");
                xPublicationDate = rs.getString("PublicationDate");
                xBookImg = rs.getString("BookImg");
                xStatus = rs.getString("Status");
                x = new Book(xBookId, xTitle, xAuthorId, xDescription, xPrice, xQuantity, xPublicationDate, xBookImg, xStatus);
                t.add(x);
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return (t);
    }

    public List<Book> getBooks2(String xxTitle) {
        List<Book> t = new ArrayList<>();
        xSql = "select * from Book where Title like '%" + xxTitle + "%'";
        int xBookId;
        String xTitle;
        int xAuthorId;
        String xDescription;
        double xPrice;
        int xQuantity;
        String xPublicationDate;
        String xBookImg;
        String xStatus;
        Book x;
        try {
            ps = con.prepareStatement(xSql);
            rs = ps.executeQuery();
            while (rs.next()) {
                xBookId = rs.getInt("BookID");
                xTitle = rs.getString("Title");
                xAuthorId = rs.getInt("AuthorID");
                xDescription = rs.getString("Description");
                xPrice = rs.getDouble("Price");
                xQuantity = rs.getInt("Quantity");
                xPublicationDate = rs.getString("PublicationDate");
                xBookImg = rs.getString("BookImg");
                xStatus = rs.getString("Status");
                x = new Book(xBookId, xTitle, xAuthorId, xDescription, xPrice, xQuantity, xPublicationDate, xBookImg, xStatus);
                t.add(x);
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return (t);
    }

    public Book getProductByID(String id) {
        xSql = "select * from Book\n"
                + "where id = ?";
        try {
            ps = con.prepareStatement(xSql);
            rs = ps.executeQuery();
            ps.setString(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                return new Book(rs.getInt(1),
                        rs.getString(2),
                        rs.getInt(3),
                        rs.getString(4),
                        rs.getDouble(5),
                        rs.getInt(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9));
            }
        } catch (Exception e) {
        }
        return null;
    }

    public void insert(Book x) {
        xSql = "INSERT INTO Book (Title, AuthorID, Description, Price, Quantity, PublicationDate, BookImage, Status) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try {
            ps.setString(1, x.getTitle());
            ps.setInt(2, x.getAuthorId());
            ps.setString(3, x.getDescription());
            ps.setDouble(4, x.getPrice());
            ps.setInt(5, x.getQuantity());
            ps.setString(6, x.getPublicationDate());
            ps.setString(7, x.getBookImage());
            ps.setString(8, x.getStatus());
            ps.executeUpdate();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void delete(String xxTitle) {
        xSql = "delete from Book where title=?";
        try {
            ps = con.prepareStatement(xSql);
            ps.setString(1, xxTitle);
            ps.executeUpdate();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
