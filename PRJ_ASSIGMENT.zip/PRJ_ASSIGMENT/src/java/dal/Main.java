package dal;
import static java.util.Collections.list;
import java.util.List;
import model.Account;
public class Main {
    public static void main(String[] args) {
        AccountDAO a = new AccountDAO();
        List<Account> accounts = a.getAccounts();
        for (Account account : accounts) {
             System.out.println("name: " + account.getName() + ", pw: " + account.getPassWord()+ ", Role: " + account.getRole());
        }
    }
}
