package dal;

import java.util.ArrayList;
import java.util.List;
import model.Author;

public class AuthorDAO extends MyDAO {

    public List<Author> getAuthors() {
        List<Author> t = new ArrayList<>();
        xSql = "select * from Author";
        int xAuthorId;
        String xAuthorName;
        String xAuthorBio;
        Author x;
        //
        try {
            ps = con.prepareStatement(xSql);
            rs = ps.executeQuery();
            while (rs.next()) {
                xAuthorId = rs.getInt("AuthorID");
                xAuthorName = rs.getString("AuthorName");
                xAuthorBio = rs.getString("AuthorBio");
                x = new Author(xAuthorId, xAuthorName, xAuthorBio);
                t.add(x);
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return (t);
    }

    public List<Author> getAuthor(String xxName) {
        List<Author> t = new ArrayList<>();
        xSql = "select * from Author where name like '%" + xxName + "%'";
        int xAuthorId;
        String xAuthorName;
        String xAuthorBio;
        Author x;
        try {
            ps = con.prepareStatement(xSql);
            rs = ps.executeQuery();
            while (rs.next()) {
                xAuthorId = rs.getInt("AuthorID");
                xAuthorName = rs.getString("AuthorName");
                xAuthorBio = rs.getString("AuthorBio");
                x = new Author(xAuthorId, xAuthorName, xAuthorBio);
                t.add(x);
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return (t);
    }
    
    public void insertAuthor(Author x) {
     xSql = "insert into Author (AuthorName,AuthorBio) values (?,?)"; 
     try {
      ps = con.prepareStatement(xSql);
      ps.setString(1, x.getAuthorName());
      ps.setString(2, x.getAuthorBio());
      ps.executeUpdate();
      ps.close();
     }     
     catch(Exception e) {
        e.printStackTrace();
     }
  }
    public void deleteAuthor(String xAuthorName) {
     xSql = "delete from Author where rollno=?";
     try {
        ps = con.prepareStatement(xSql);
        ps.setString(1, "xAuthorName");
        ps.executeUpdate();
        //con.commit();
        ps.close();
     }
     catch(Exception e) {
        e.printStackTrace();
     }
  }
    public void update(int xAuthorId, Author x) {
     xSql = "update Author set AuthorName=?, AuthorBio=? where AuthorId=?";
     try {      
        ps = con.prepareStatement(xSql);
        ps.setString(1, x.getAuthorName());
        ps.setString(2, x.getAuthorBio());
        ps.executeUpdate();
        ps.close();
     }
      catch(Exception e) {
        e.printStackTrace();
      }
  }
    

}
