package dal;

import java.util.ArrayList;
import java.util.List;
import model.OrderDetail;

public class OrderDetailDAO extends MyDAO {

    public List<OrderDetail> getOrderDetails() {
        List<OrderDetail> t = new ArrayList<>();
        xSql = "select * from OrderDetail";
        int xOrderDetailID;
        int xOrderId;
        int xBookId;
        int xQuantity;
        double xPrice;
        OrderDetail x;
        try {
            ps = con.prepareStatement(xSql);
            rs = ps.executeQuery();
            while (rs.next()) {
                xOrderDetailID = rs.getInt("OrderDetailID");
                xOrderId = rs.getInt("OrderId");
                xBookId = rs.getInt("BookId");
                xQuantity = rs.getInt("Quantity");
                xPrice = rs.getDouble("Price");
                x = new OrderDetail(xOrderDetailID, xOrderId, xBookId, xQuantity, xBookId);
                t.add(x);
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return (t);
    }

    public void insert(OrderDetail x) {
        xSql = "insert into OrderDetail (OrderId,BookId,Quantity,Price) values (?,?,?,?)";
        try {
            ps = con.prepareStatement(xSql);
            ps.setInt(1, x.getOrderId());
            ps.setInt(2, x.getBookId());
            ps.setInt(3, x.getQuantity());
            ps.setDouble(4, x.getPrice());
            ps.executeUpdate();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
}
