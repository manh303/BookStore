package dal;

import java.util.ArrayList;
import java.util.List;
import model.*;

public class AccountDAO extends MyDAO {

    public List<Account> getAccounts() {
        List<Account> t = new ArrayList<>();
        xSql = "select * from Account";
        int xAccountId;
        String xUserName, xPassWord, xRole, xAvatarImg, xAddress, xStatus;
        Account x;
        try {
            ps = con.prepareStatement(xSql);
            rs = ps.executeQuery();
            while (rs.next()) {
                xAccountId = rs.getInt("AccountID");
                xUserName = rs.getString("UserName");
                xPassWord = rs.getString("Password");
                xRole = rs.getString("Role");
                xAvatarImg = rs.getString("AvatarImage");
                xAddress = rs.getString("Address");
                xStatus = rs.getString("Status");
                x = new Account(xAccountId, xUserName, xPassWord, xRole, xAvatarImg, xAddress, xStatus);
                t.add(x);
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return (t);
    }

    public List<Account> getAccounts(String xxUserName) {
        List<Account> t = new ArrayList<>();
        xSql = "select * from Student where UserName like '%" + xxUserName + "%'";
        int xId;
        String xUserName, xPassWord, xRole, xAvatarImg, xAddress, xStatus;
        Account x;
        try {
            ps = con.prepareStatement(xSql);
            rs = ps.executeQuery();
            while (rs.next()) {
                xId = rs.getInt("AccountID");
                xUserName = rs.getString("UserName");
                xPassWord = rs.getString("Password");
                xRole = rs.getString("Role");
                xAvatarImg = rs.getString("AvatarImage");
                xAddress = rs.getString("Address");
                xStatus = rs.getString("Status");
                x = new Account(xId, xUserName, xPassWord, xRole, xAvatarImg, xAddress, xStatus);
                t.add(x);
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return (t);
    }

    public Account findAccountById(int accountId) {
        String query = "SELECT * FROM Account WHERE AccountID = ?";
        try {
            ps.setInt(1, accountId);

            rs = ps.executeQuery();
            if (rs.next()) {
                String userName = rs.getString("UserName");
                String password = rs.getString("Password");
                String role = rs.getString("Role");
                String avatarImage = rs.getString("AvatarImage");
                String address = rs.getString("Address");
                String status = rs.getString("Status");

                return new Account(accountId, userName, password, role, avatarImage, address, status);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean insert(Account x) {
        xSql = "INSERT INTO Account (UserName, Password, Role, AvatarImage, Address, Status) VALUES ('?', '?', '?', NULL, '?', 'Active');";
        try {
            ps = con.prepareStatement(xSql);
            ps.setString(1, x.getName());
            ps.setString(2, x.getPassWord());
            ps.setString(3, x.getRole());
            ps.setString(4, x.getAddress());
            int done = ps.executeUpdate();
            return done > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean updateAccount(int accountId, String newPassword, String newAvatarImage, String newAddress) {
        String query = "UPDATE Account SET Password = ?, AvatarImage = ?, Address = ? WHERE AccountID = ?";
        try {
            ps.setString(1, newPassword);
            ps.setString(2, newAvatarImage);
            ps.setString(3, newAddress);
            ps.setInt(4, accountId);

            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
