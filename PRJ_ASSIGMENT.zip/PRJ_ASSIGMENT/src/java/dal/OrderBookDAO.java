package dal;

import java.util.ArrayList;
import java.util.List;
import model.OrderBook;

public class OrderBookDAO extends MyDAO {

    public List<OrderBook> getOrderBooks() {
        List<OrderBook> t = new ArrayList<>();
        xSql = "select * from OrderBook";
        int xOrderId;
        int xCustomerId;
        String xOrderDate;
        double xTotal;
        String xAddress;
        String xStatus;
        OrderBook x;
        
        try {
            ps = con.prepareStatement(xSql);
            rs = ps.executeQuery();
            while (rs.next()) {
                xOrderId = rs.getInt("OrderId");
                xCustomerId = rs.getInt("CustomerId");
                xOrderDate = rs.getString("OrderDate");
                xTotal = rs.getDouble("Total");
                xAddress = rs.getString("Address");
                xStatus = rs.getString("Status");
                x = new OrderBook(xOrderId, xCustomerId, xCustomerId, xOrderDate, xOrderId, xAddress, xStatus);
                t.add(x);
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return (t);
    }
    public void insertOrderBook(OrderBook x) {
     xSql = "INSERT INTO OrderBook (CustomerID, OrderDate, Total, Address,Status) VALUES (?, ?, ?, ?,?)"; 
     try {
      ps = con.prepareStatement(xSql);
      ps.setInt(1, x.getCustomerId());
      ps.setString(2, x.getOrderDate());
      ps.setInt(3, x.getTotal());
      ps.setString(4, x.getAddress());
      ps.setString(5, x.getStatus());
      ps.executeUpdate();
      ps.close();
     }     
     catch(Exception e) {
        e.printStackTrace();
     }
  }
    
    public void update(String xRollno, OrderBook x) {
     xSql = "update Student set CustomerID =?, Total=?, Address =?, Status = ? where OrderBookId=?";
     try {      
        ps = con.prepareStatement(xSql);
        ps.setInt(1, x.getCustomerId());
        ps.setInt(2, x.getTotal());
        ps.setString(3, x.getAddress());
        ps.setString(4, x.getStatus());
        ps.executeUpdate();
        ps.close();
     }
      catch(Exception e) {
        e.printStackTrace();
      }
  }
    
}
