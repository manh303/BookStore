package model;
public class Book {
    private int bookId;
    private String title;
    private int authorId;
    private String description;
    private double price;
    private int quantity;
    private String publicationDate;
    private String bookImage;
    private String status;

    public Book() {
    }

    public Book(int bookId, String title, int authorId, String description, double price, int quantity, String publicationDate, String bookImage, String status) {
        this.bookId = bookId;
        this.title = title;
        this.authorId = authorId;
        this.description = description;
        this.price = price;
        this.quantity = quantity;
        this.publicationDate = publicationDate;
        this.bookImage = bookImage;
        this.status = status;
    }

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getAuthorId() {
        return authorId;
    }

    public void setAuthorId(int authorId) {
        this.authorId = authorId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getPublicationDate() {
        return publicationDate;
    }

    public void setPublicationDate(String publicationDate) {
        this.publicationDate = publicationDate;
    }

    public String getBookImage() {
        return bookImage;
    }

    public void setBookImage(String bookImage) {
        this.bookImage = bookImage;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    

    
    
}
