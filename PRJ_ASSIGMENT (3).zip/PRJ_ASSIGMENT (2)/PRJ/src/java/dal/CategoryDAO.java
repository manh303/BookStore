package dal;

import java.util.ArrayList;
import java.util.List;
import model.Category;

public class CategoryDAO extends MyDAO {

    public List<Category> getCategorys() {
        List<Category> t = new ArrayList<>();
        xSql = "select * from Category";
        int xCategoryId;
        String xCategoryName;

        Category x;
        try {
            ps = con.prepareStatement(xSql);
            rs = ps.executeQuery();
            while (rs.next()) {
                xCategoryId = rs.getInt("CategoryId");
                xCategoryName = rs.getString("CategoryName");
                x = new Category(xCategoryId, xCategoryName);
                t.add(x);
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return (t);
    }

    public List<String> getCategoryNames() {
        List<String> t = new ArrayList<>();
        xSql = "select CategoryName from Category";
        String xCategoryName;
        try {
            ps = con.prepareStatement(xSql);
            rs = ps.executeQuery();
            while (rs.next()) {
                xCategoryName = rs.getString("CategoryName");
                t.add(xCategoryName);
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return (t);
    }

    public void insert(Category x) {
        xSql = "insert into Category (categoryName) values (?)";
        try {
            ps = con.prepareStatement(xSql);
            ps.setString(1, x.getCategoryName());
            ps.executeUpdate();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void delete(String categoryId) {
        xSql = "delete from Category where categoryId=?";
        try {
            ps = con.prepareStatement(xSql);
            ps.setString(1, categoryId);
            ps.executeUpdate();
            //con.commit();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void update(String xRollno, Category x) {
        xSql = "update Student set Category where CategoryId=?";
        try {
            ps = con.prepareStatement(xSql);
            ps.setString(1, x.getCategoryName());
            ps.executeUpdate();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<String> getListCategory(int xxBookId) {
        List<String> lc = new ArrayList<>();
        xSql = "SELECT Category.CategoryName "
                + "FROM Book "
                + "INNER JOIN Category ON Book.CategoryID = Category.CategoryID "
                + "WHERE Book.BookID = ? ";

        String xCategoryName;
        try {
            ps = con.prepareStatement(xSql);
            ps.setInt(1, xxBookId);
            rs = ps.executeQuery();
            while (rs.next()) {
                xCategoryName = rs.getString("CategoryName");
                lc.add(xCategoryName);
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lc;
    }

    public static void main(String[] args) {
        CategoryDAO c = new CategoryDAO();
        List<String> lc = c.getListCategory(1);
        if (lc == null) {
            System.out.println("List empty");
        } else {
            for (String string : lc) {
                System.out.println(string);
            }
        }
    }

    public String getBookCategoryName(int xxBookId) {
        xSql = "select categoryName from category where categoryId= ?";

        String xCategoryName = null;
        try {
            ps = con.prepareStatement(xSql);
            ps.setInt(1, xxBookId);
            rs = ps.executeQuery();
            while (rs.next()) {
                xCategoryName = rs.getString("CategoryName");
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return xCategoryName;
    }

    public int getBookCategoryId(String xxCategoryName) {
        xSql = "select CategoryID  from category where CategoryName  = ?";

        int xCategoryId = 0;
        try {
            ps = con.prepareStatement(xSql);
            ps.setString(1, xxCategoryName);
            rs = ps.executeQuery();
            while (rs.next()) {
                xCategoryId = rs.getInt("CategoryId");
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return xCategoryId;
    }

}
