package dal;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import model.*;

public class AccountDAO extends MyDAO {

    public List<Account> getAccounts() {
        List<Account> t = new ArrayList<>();
        xSql = "select * from Account";
        int xAccountId;
        String xUserName, xPassWord, xRole, xAvatarImg, xAddress, xStatus;
        Account x;
        try {
            ps = con.prepareStatement(xSql);
            rs = ps.executeQuery();
            while (rs.next()) {
                xAccountId = rs.getInt("AccountID");
                xUserName = rs.getString("UserName");
                xPassWord = rs.getString("Password");
                xRole = rs.getString("Role");
                xAvatarImg = rs.getString("AvatarImage");
                xAddress = rs.getString("Address");
                xStatus = rs.getString("Status");
                x = new Account(xAccountId, xUserName, xPassWord, xRole, xAvatarImg, xAddress, xStatus);
                t.add(x);
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return (t);
    }

    public Account getAccounts(String xxUserName) {
        xSql = "select * from Account where UserName like '%" + xxUserName + "%'";
        int xId;
        String xUserName, xPassWord, xRole, xAvatarImg, xAddress, xStatus;
        Account x = null;
        try {
            ps = con.prepareStatement(xSql);
            rs = ps.executeQuery();
            while (rs.next()) {
                xId = rs.getInt("AccountID");
                xUserName = rs.getString("UserName");
                xPassWord = rs.getString("Password");
                xRole = rs.getString("Role");
                xAvatarImg = rs.getString("AvatarImage");
                xAddress = rs.getString("Address");
                xStatus = rs.getString("Status");
                x = new Account(xId, xUserName, xPassWord, xRole, xAvatarImg, xAddress, xStatus);
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return x;
    }

    public Account findAccountById(int accountId) {

        xSql = "SELECT * FROM Account WHERE AccountID = ?";
        try {
            ps = con.prepareStatement(xSql);
            ps.setInt(1, accountId);

            rs = ps.executeQuery();
            if (rs.next()) {
                String userName = rs.getString("UserName");
                String password = rs.getString("Password");
                String role = rs.getString("Role");
                String avatarImage = rs.getString("AvatarImage");
                String address = rs.getString("Address");
                String status = rs.getString("Status");

                return new Account(accountId, userName, password, role, avatarImage, address, status);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public void insert(Account x) {
        xSql = "INSERT INTO Account (UserName, Password, Role, AvatarImage, Address, Status) VALUES (?, ?, 'Customer', NULL, ?, 'Active')";
        try {
            ps = con.prepareStatement(xSql);
            ps.setString(1, x.getName());
            ps.setString(2, x.getPassWord());
            ps.setString(3, x.getAddress());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String getAddByCusId(int accId) {
        xSql = "SELECT Address FROM Account WHERE AccountID = ?";
        try {
            ps = con.prepareStatement(xSql);
            ps.setInt(1, accId);
            rs = ps.executeQuery();
            if (rs.next()) {
                String add = rs.getString("Address");
                return add;

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public void updateAccount(int accountId, String newPassword, String newAvatarImage, String newAddress) {
        xSql = "UPDATE Account SET Password = ?, AvatarImage = ?, Address = ? WHERE AccountID = ?";
        try {
            ps = con.prepareStatement(xSql);
            ps.setString(1, newPassword);
            ps.setString(2, newAvatarImage);
            ps.setString(3, newAddress);
            ps.setInt(4, accountId);

            ps.executeUpdate();
            ps.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        AccountDAO a = new AccountDAO();
        Account ba = a.findAccountById(1);
        System.out.println(ba);

    }
}
