package dal;

import java.util.ArrayList;
import java.util.List;
import model.Customer;

public class CustomerDAO extends MyDAO {

    public List<Customer> getCustomers() {
        List<Customer> t = new ArrayList<>();
        xSql = "select * from Customer";

        int xCustomerId;
        int xAccountId;
        Customer x;
        try {
            ps = con.prepareStatement(xSql);
            rs = ps.executeQuery();
            while (rs.next()) {
                xCustomerId = rs.getInt("CustomerId");
                xAccountId = rs.getInt("AccountId");
                x = new Customer(xCustomerId, xAccountId);
                t.add(x);
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return (t);
    }
    public int getCustomerIdbyA(int accountId){
        xSql = "select * from customer where AccountId = ?";
        int cusId = 0;
        try {
            ps = con.prepareStatement(xSql);
            rs= ps.executeQuery();
            
            return cusId = rs.getInt("CustomerId");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cusId;
               
    }
    public int getAccIdByCusId(int cusId){
        xSql = "select * from customer where cusId = ?";
        int accId = 0;
        try {
            ps = con.prepareStatement(xSql);
            rs= ps.executeQuery();
            
            return cusId = rs.getInt("AccountId");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return accId;
               
    }
}
