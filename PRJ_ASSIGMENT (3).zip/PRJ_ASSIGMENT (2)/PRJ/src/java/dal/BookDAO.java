package dal;

import java.util.ArrayList;
import java.util.List;
import model.Book;
import java.util.Date;

public class BookDAO extends MyDAO {

    public List<Book> getBooks() {
        List<Book> t = new ArrayList<>();
        xSql = "select * from Book";
        int xBookId;
        String xTitle;
        int xAuthorId;
        String xDescription;
        double xPrice;
        int xQuantity;
        Date xPublicationDate;
        String xBookImg;
        int xBookCategory;
        String xStatus;
        Book x;
        try {
            ps = con.prepareStatement(xSql);
            rs = ps.executeQuery();
            while (rs.next()) {
                xBookId = rs.getInt("BookID");
                xTitle = rs.getString("Title");
                xAuthorId = rs.getInt("AuthorID");
                xDescription = rs.getString("Description");
                xPrice = rs.getDouble("Price");
                xQuantity = rs.getInt("Quantity");
                xPublicationDate = rs.getDate("PublicationDate");
                xBookImg = rs.getString("BookImage");
                xBookCategory = rs.getInt("CategoryID");
                xStatus = rs.getString("Status");
                x = new Book(xBookId, xTitle, xAuthorId, xDescription, xPrice, xQuantity, xPublicationDate, xBookImg, xBookCategory, xStatus);
                t.add(x);
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return (t);
    }

    public List<Book> getBooks(String xxTitle) {
        List<Book> t = new ArrayList<>();
        xSql = "select * from Book where Title like '%" + xxTitle + "%'";
        int xBookId;
        String xTitle;
        int xAuthorId;
        String xDescription;
        double xPrice;
        int xQuantity;
        Date xPublicationDate;
        String xBookImg;
        int xBookCategory;
        String xStatus;
        Book x;
        try {
            ps = con.prepareStatement(xSql);
            rs = ps.executeQuery();
            while (rs.next()) {
                xBookId = rs.getInt("BookID");
                xTitle = rs.getString("Title");
                xAuthorId = rs.getInt("AuthorID");
                xDescription = rs.getString("Description");
                xPrice = rs.getDouble("Price");
                xQuantity = rs.getInt("Quantity");
                xPublicationDate = rs.getDate("PublicationDate");
                xBookImg = rs.getString("BookImage");
                xBookCategory = rs.getInt("CategoryID");
                xStatus = rs.getString("Status");
                x = new Book(xBookId, xTitle, xAuthorId, xDescription, xPrice, xQuantity, xPublicationDate, xBookImg, xBookCategory, xStatus);
                t.add(x);
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return (t);
    }

    public Book getBook(int xxBookId) {
        xSql = "SELECT * FROM Book WHERE BookID = ?";
        Book x = null;
        try {
            ps = con.prepareStatement(xSql);
            ps.setInt(1, xxBookId);
            rs = ps.executeQuery();
            if (rs.next()) {
                int xBookId = rs.getInt("BookID");
                String xTitle = rs.getString("Title");
                int xAuthorId = rs.getInt("AuthorID");
                String xDescription = rs.getString("Description");
                double xPrice = rs.getDouble("Price");
                int xQuantity = rs.getInt("Quantity");
                Date xPublicationDate = rs.getDate("PublicationDate");
                String xBookImg = rs.getString("BookImage");
                int xBookCategory = rs.getInt("CategoryID");
                String xStatus = rs.getString("Status");

                x = new Book(xBookId, xTitle, xAuthorId, xDescription, xPrice, xQuantity, xPublicationDate, xBookImg, xBookCategory, xStatus);
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return x;
    }

    public void insert(Book x) {
        xSql = "INSERT INTO Book (Title, AuthorID, Description, Price, Quantity, PublicationDate, BookImage, CategoryID, Status) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try {
            ps = con.prepareStatement(xSql);
            ps.setString(1, x.getTitle());
            ps.setInt(2, x.getAuthorId());
            ps.setString(3, x.getDescription());
            ps.setDouble(4, x.getPrice());
            ps.setInt(5, x.getQuantity());
            ps.setDate(6, new java.sql.Date(x.getPublicationDate().getTime()));
            ps.setString(7, x.getBookImage());
            ps.setInt(8, x.getBookCategory());
            ps.setString(9, x.getStatus());
            ps.executeUpdate();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void delete(int xxBookId) {
        xSql = "delete from Book where bookid=?";
        try {
            ps = con.prepareStatement(xSql);
            ps.setInt(1, xxBookId);
            ps.executeUpdate();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updateBook(int bookId, String xTitle, int xAuthorId, String xDescription, double xPrice, int xQuantity, Date xPublicationDate, String xBookImg, int xBookCategory, String xStatus) {
        xSql = "UPDATE Book SET Title=?, AuthorID=?, Description=?, Price=?, Quantity=?, PublicationDate=?, BookImage=?, CategoryID=?, Status=? WHERE BookID=?";
        try {
            ps = con.prepareStatement(xSql);
            ps.setString(1, xTitle);
            ps.setInt(2, xAuthorId);
            ps.setString(3, xDescription);
            ps.setDouble(4, xPrice);
            ps.setInt(5, xQuantity);
            ps.setDate(6, new java.sql.Date(xPublicationDate.getTime()));
            ps.setString(7, xBookImg);
            ps.setInt(8, xBookCategory);
            ps.setString(9, xStatus);
            ps.setInt(10, bookId);
            ps.executeUpdate();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public static void main(String[] args) {
        try{
            BookDAO dao = new BookDAO();
            List<Book> list = dao.getBooks();
            for(Book b : list )
            System.out.println(b);
        }
        catch(Exception e){
            
        }
    }

}
