package dal;

import java.util.ArrayList;
import java.util.List;
import model.FeedBack;

public class FeedbackDAO extends MyDAO {

    public List<FeedBack> getFeedBacks() {
        List<FeedBack> t = new ArrayList<>();
        xSql = "select * from FeedBack";
        int xFeedbackID, xBookID, xRating;
        String xComment;
        FeedBack x;
        try {
            ps = con.prepareStatement(xSql);
            rs = ps.executeQuery();
            while (rs.next()) {
                xFeedbackID = rs.getInt("FeedbackID");
                xBookID = rs.getInt("BookID");
                xRating = rs.getInt("Rating");
                xComment = rs.getString("Comment");
                x = new FeedBack(xFeedbackID, xBookID, xRating, xComment);
                t.add(x);
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return (t);
    }

    public void insert(FeedBack x) {
        xSql = "INSERT INTO Feedback (BookID, Rating, Comment) VALUES (?, ?, ?)";
        try {
            ps = con.prepareStatement(xSql);
            ps.setInt(1, x.getBookId());
            ps.setInt(2, x.getRating());
            ps.setString(3, x.getComment());
            ps.executeUpdate();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    

    public void update(int FeedbackID, FeedBack x ) {
        xSql = "UPDATE Feedback SET Rating = ?, Comment = ? WHERE FeedbackID = ?";
        try {
            ps = con.prepareStatement(xSql);
            ps.setInt(1, x.getRating());
            ps.setString(2, x.getComment());
            ps.setInt(3, FeedbackID);
            ps.executeUpdate();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
