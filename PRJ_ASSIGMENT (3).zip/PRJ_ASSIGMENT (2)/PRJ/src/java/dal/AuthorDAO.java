package dal;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Author;

public class AuthorDAO extends MyDAO {

    public List<Author> getAuthors() {
        List<Author> t = new ArrayList<>();
        xSql = "select * from Author";
        int xAuthorId;
        String xAuthorName;
        String xAuthorBio;
        Author x;
        //
        try {
            ps = con.prepareStatement(xSql);
            rs = ps.executeQuery();
            while (rs.next()) {
                xAuthorId = rs.getInt("AuthorID");
                xAuthorName = rs.getString("AuthorName");
                xAuthorBio = rs.getString("AuthorBio");
                x = new Author(xAuthorId, xAuthorName, xAuthorBio);
                t.add(x);
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return (t);
    }
    public List<String> getListAuthorsName() {
        List<String> t = new ArrayList<>();
        xSql = "select authorname from Author";

        String xAuthorName;

        //
        try {
            ps = con.prepareStatement(xSql);
            rs = ps.executeQuery();
            while (rs.next()) {
                xAuthorName = rs.getString("AuthorName");
                t.add(xAuthorName);
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return (t);
    }

    public Author getAuthor(int id) {
        xSql = "select * from Author where AuthorId =  ? ";
        String xAuthorName;
        String xAuthorBio;
        Author x = null;
        try {
            ps = con.prepareStatement(xSql);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {

                xAuthorName = rs.getString("AuthorName");
                xAuthorBio = rs.getString("AuthorBio");
                x = new Author(id, xAuthorName, xAuthorBio);
                
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return (x);
    }
    public int getAuthorId(String xxName) {
        xSql = "SELECT AuthorId FROM Author WHERE name LIKE ?";
        int xAuthorId = 0;

        try {
            ps = con.prepareStatement(xSql);
            rs = ps.executeQuery();
            while (rs.next()) {
                xAuthorId = rs.getInt("AuthorId");
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return (xAuthorId);
    }

    public String getAuthorName(int xxAuthorId) throws SQLException {
        String nameAuthor = null;
        xSql = "SELECT AuthorName FROM Author WHERE AuthorID = ?";
        try {
            ps = con.prepareStatement(xSql);
            ps.setInt(1, xxAuthorId);
            rs = ps.executeQuery();
            if (rs.next()) {
                nameAuthor = rs.getString("AuthorName");
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return nameAuthor;
    }
    public String getAuthorBio(int xxAuthorId) {
        String authorBio = null;
        xSql = "SELECT AuthorBio FROM Author WHERE AuthorID = ?";
        try {
            ps = con.prepareStatement(xSql);
            ps.setInt(1, xxAuthorId);
            rs = ps.executeQuery();
            if (rs.next()) {
                authorBio = rs.getString("AuthorName");
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return authorBio;
    }

    public void insertAuthor(Author x) {
        xSql = "insert into Author (AuthorName,AuthorBio) values (?,?)";
        try {
            ps = con.prepareStatement(xSql);
            ps.setString(1, x.getAuthorName());
            ps.setString(2, x.getAuthorBio());
            ps.executeUpdate();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deleteAuthor(String xAuthorName) {
        xSql = "delete from Author where rollno=?";
        try {
            ps = con.prepareStatement(xSql);
            ps.setString(1, "xAuthorName");
            ps.executeUpdate();
            //con.commit();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void update(int xAuthorId, String authorName, String authorBio) {
        xSql = "update Author set AuthorName=?, AuthorBio=? where AuthorId=?";
        try {
            ps = con.prepareStatement(xSql);
            ps.setString(1, authorName);
            ps.setString(2, authorBio);
            ps.executeUpdate();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static void main(String[] args) {
        AuthorDAO a= new AuthorDAO();
        System.out.println(a.getAuthor(1));
    }

}
