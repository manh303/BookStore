package model;

import java.util.Date;

public class Book {
    private int bookId;
    private String title;
    private int authorId;
    private String description;
    private double price;
    private int quantity;
    private Date publicationDate;
    private String bookImage;
    private int bookCategory;
    private String status;

    public Book() {
    }

    public Book(int bookId, String title, int authorId, String description, double price, int quantity, Date publicationDate, String bookImage, int bookCategory, String status) {
        this.bookId = bookId;
        this.title = title;
        this.authorId = authorId;
        this.description = description;
        this.price = price;
        this.quantity = quantity;
        this.publicationDate = publicationDate;
        this.bookImage = bookImage;
        this.bookCategory = bookCategory;
        this.status = status;
    }

    public Book(String title, int authorId, String description, double price, int quantity, Date publicationDate, String bookImage, int bookCategory, String status) {
        this.title = title;
        this.authorId = authorId;
        this.description = description;
        this.price = price;
        this.quantity = quantity;
        this.publicationDate = publicationDate;
        this.bookImage = bookImage;
        this.bookCategory = bookCategory;
        this.status = status;
    }
    

    public int getBookId() {
        return bookId;
    }

    public String getTitle() {
        return title;
    }

    public int getAuthorId() {
        return authorId;
    }

    public String getDescription() {
        return description;
    }

    public double getPrice() {
        return price;
    }

    public int getQuantity() {
        return quantity;
    }

    public Date getPublicationDate() {
        return publicationDate;
    }

    public String getBookImage() {
        return bookImage;
    }

    public int getBookCategory() {
        return bookCategory;
    }

    public String getStatus() {
        return status;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setAuthorId(int authorId) {
        this.authorId = authorId;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public void setPublicationDate(Date publicationDate) {
        this.publicationDate = publicationDate;
    }

    public void setBookImage(String bookImage) {
        this.bookImage = bookImage;
    }

    public void setBookCategory(int bookCategory) {
        this.bookCategory = bookCategory;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Book{" + "bookId=" + bookId + ", title=" + title + ", authorId=" + authorId + ", description=" + description + ", price=" + price + ", quantity=" + quantity + ", publicationDate=" + publicationDate + ", bookImage=" + bookImage + ", bookCategory=" + bookCategory + ", status=" + status + '}';
    }
    

    

    

    
    
}
