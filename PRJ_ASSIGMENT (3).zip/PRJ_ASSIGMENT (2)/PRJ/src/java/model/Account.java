package model;
public class Account {
    private int id;
    private String name;
    private String passWord;
    private String role;
    private String avatarImg;
    private String address;
    private String status;

    public Account() {
    }

    public Account(int id, String name, String passWord, String role, String avatarImg, String address, String status) {
        this.id = id;
        this.name = name;
        this.passWord = passWord;
        this.role = role;
        this.avatarImg = avatarImg;
        this.address = address;
        this.status = status;
    }

    public Account(String name, String passWord) {
        this.name = name;
        this.passWord = passWord;
    }
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassWord() {
        return passWord;
    }

    public void setPassWord(String passWord) {
        this.passWord = passWord;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getAvatarImg() {
        return avatarImg;
    }

    public void setAvatarImg(String avatarImg) {
        this.avatarImg = avatarImg;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Account{" + "id=" + id + ", name=" + name + ", passWord=" + passWord + ", role=" + role + ", avatarImg=" + avatarImg + ", address=" + address + ", status=" + status + '}';
    }
    

   
    
}
