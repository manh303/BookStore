/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import dal.AccountDAO;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Account;

/**
 *
 * @author phaml
 */
@WebServlet(name = "UpdateAccount", urlPatterns = {"/updateaccount"})
public class UpdateAccount extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet UpdateAccount</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet UpdateAccount at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter pr = response.getWriter();
        String xxId = request.getParameter("id");
        int xId = Integer.parseInt(xxId);
        AccountDAO u = new AccountDAO();
        Account x = u.findAccountById(xId);

        request.setAttribute("x", x);
        request.getRequestDispatcher("updateaccount.jsp").forward(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter pr = response.getWriter();
        String newPassWord, newAvaImg, newAddress;
        String name;
        int id;
        // Sử dụng Integer.parseInt() để chuyển đổi chuỗi thành số nguyên
        id = Integer.parseInt(request.getParameter("id"));
        name = request.getParameter("name");
        newPassWord = request.getParameter("password");
        newAvaImg = request.getParameter("img");
        newAddress = request.getParameter("address");
        boolean isOk = true;
        if (newPassWord == null || newPassWord.equals("")) {
            isOk = false;
        }
        if (name == null || name.trim().length() == 0) {
            isOk = false;
        }
        if (newAvaImg == null || newAvaImg.trim().length() == 0) {
            isOk = false;
        }
        if (newAddress == null || newAddress.trim().length() == 0) {
            isOk = false;
        }
        if (!isOk) {
            Account x = new Account(id, name, newPassWord, "Customer", newAvaImg, newAddress, "Active");
            request.setAttribute("x", x);
            request.setAttribute("msg", "<h2> nhập lại</h2>");
            request.getRequestDispatcher("updateaccount.jsp").forward(request, response);
            return;
        }
        AccountDAO u = new AccountDAO();
        u.updateAccount(id, newPassWord, newAvaImg, newAddress);
        response.sendRedirect("listofaccount");
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
