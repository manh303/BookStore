/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import dal.AuthorDAO;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import dal.*;
import dal.CategoryDAO;
import model.Book;
import java.sql.Date;
import java.util.List;
import model.Author;

/**
 *
 * @author phaml
 */
@WebServlet(name = "UpdateBookServlet", urlPatterns = {"/updatebook"})
public class UpdateBookServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet UpdateBookServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet UpdateBookServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String xxId = request.getParameter("bookid");
        int xId = Integer.parseInt(xxId);
        BookDAO u = new BookDAO();
        Book x = u.getBook(xId);
        request.setAttribute("x", x);
        request.getRequestDispatcher("updatebook.jsp").forward(request, response);

    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter pr = response.getWriter();
        int bookId, quantity;
        String title, author, descripstion;
        double price;
        String bookImg, sPublicDate;
        String category;
        String status;
        Date xPublicDate;
        AuthorDAO a = new AuthorDAO();

        bookId = Integer.parseInt(request.getParameter("bookid"));
        title = request.getParameter("title");
        author = request.getParameter("author");
        descripstion = request.getParameter("description");
        quantity = Integer.parseInt(request.getParameter("quantity"));
        price = Double.parseDouble(request.getParameter("price"));
        sPublicDate = request.getParameter("publicationDate");
        xPublicDate = Date.valueOf(sPublicDate);
        bookImg = request.getParameter("img");
        category = request.getParameter("category");
        status = request.getParameter("status");
        boolean isOk = true;
        if (title == null || title.trim().length() == 0) {
            isOk = false;
        }

        if (descripstion == null || descripstion.trim().length() == 0) {
            isOk = false;
        }
        if (quantity == 0) {
            isOk = false;
        }
        if (price == 0) {
            isOk = false;
        }
//        if (bookImg == null || bookImg.trim().length() == 0) {
//            isOk = false;
//        }
        if (status == null || status.trim().length() == 0) {
            isOk = false;
        }
        if (!isOk) {
            int xxAuthorId = a.getAuthorId(author);
            CategoryDAO c = new CategoryDAO();
            int xxCategoryId = c.getBookCategoryId(category);
            Book b = new Book(bookId, title, xxAuthorId, descripstion, price, quantity, xPublicDate, bookImg, xxCategoryId, status);
            request.setAttribute("x", b);
            request.getRequestDispatcher("updatebook.jsp").forward(request, response);
        }
        int xxAuthorId = a.getAuthorId(author);
        CategoryDAO c = new CategoryDAO();
        int xxCategoryId = c.getBookCategoryId(category);
        BookDAO b = new BookDAO();

        b.updateBook(bookId, title, xxAuthorId, descripstion, price, quantity, xPublicDate, bookImg, xxCategoryId, status);

        response.sendRedirect("listofbook");
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
