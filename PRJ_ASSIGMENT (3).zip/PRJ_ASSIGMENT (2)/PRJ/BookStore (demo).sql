﻿--Using SQL ServerQuery
DROP DATABASE IF EXISTS BookStore;
GO
CREATE DATABASE BookStore;
GO
USE BookStore;
GO


CREATE TABLE Account (
    AccountID INT IDENTITY(1,1) PRIMARY KEY,
    UserName VARCHAR(50) NOT NULL UNIQUE,
    Password VARCHAR(255) NOT NULL,
    Role VARCHAR(20) DEFAULT('Customer'),
    AvatarImage VARCHAR(MAX),
    Address NVARCHAR(MAX),
    Status VARCHAR(20) DEFAULT('Active'),
    CONSTRAINT P_Role CHECK (Role IN ('Customer', 'Employee', 'Admin')),
    CONSTRAINT P_Status CHECK (Status IN ('Active', 'Inactive'))
);

CREATE TABLE Customer (
    CustomerID INT IDENTITY(1,1) PRIMARY KEY,
    AccountID INT FOREIGN KEY REFERENCES Account(AccountID),
);



CREATE TABLE Category (
    CategoryID INT PRIMARY KEY IDENTITY(1,1),
    CategoryName NVARCHAR(MAX) NOT NULL
);

CREATE TABLE Author (
    AuthorID INT PRIMARY KEY IDENTITY(1,1),
    AuthorName NVARCHAR(MAX) NOT NULL,
    AuthorBio NTEXT
);

CREATE TABLE Book (
    BookID INT PRIMARY KEY IDENTITY(1,1),
    Title NVARCHAR(MAX) NOT NULL,
    AuthorID INT NOT NULL,
	Description NVARCHAR(MAX),
    Price DECIMAL(10, 2) NOT NULL,
    Quantity INT NOT NULL,
    PublicationDate DATE,
    BookImage VARCHAR(MAX),
    CategoryID INT, 
    Status VARCHAR(20) DEFAULT('Active'),
    CONSTRAINT P_Price CHECK (Price >= 0),
    FOREIGN KEY (CategoryID) REFERENCES Category(CategoryID),
    FOREIGN KEY (AuthorID) REFERENCES Author(AuthorID),
    CONSTRAINT B_Status CHECK (Status IN ('Active', 'Inactive'))
);

CREATE TABLE OrderBook (
    OrderID INT PRIMARY KEY IDENTITY(1,1),
    CustomerID INT,
    OrderDate DATETIME DEFAULT GETDATE(),
    Total DECIMAL(10, 2) NOT NULL,
    Address NVARCHAR(MAX) NOT NULL,
    Status VARCHAR(20) DEFAULT('Pending'),
    FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID),
    CONSTRAINT O_Status CHECK (Status IN ('Pending', 'Delivering', 'Delivered', 'Cancelled'))
);

CREATE TABLE OrderDetail (
    OrderDetailID INT PRIMARY KEY IDENTITY(1,1),
    OrderID INT NOT NULL,
    BookID INT NOT NULL,
    Quantity INT NOT NULL,
    Price DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (OrderID) REFERENCES OrderBook(OrderID),
    FOREIGN KEY (BookID) REFERENCES Book(BookID),
    CONSTRAINT P_Quantity CHECK (Quantity >= 0)
);

CREATE TABLE Feedback (
    FeedbackID INT PRIMARY KEY IDENTITY(1,1),    
    BookID INT NOT NULL,
	Rating INT NOT NULL,
    Comment NVARCHAR(MAX),
    FOREIGN KEY (BookID) REFERENCES Book(BookID),
);

INSERT INTO Account (UserName, Password, Role)
VALUES ('admin', '123', 'Admin');

INSERT INTO Account (UserName, Password, Role)
VALUES ('vupl', '123', 'Customer');


INSERT INTO Account (UserName, Password, Role)
VALUES ('manhnd', '123', 'Customer');

INSERT INTO Account (UserName, Password, Role)
VALUES ('longnt', '123', 'Customer');

INSERT INTO Account (UserName, Password, Role)
VALUES ('locct', '123', 'Customer');


INSERT INTO Customer (AccountID)
VALUES (2), 
       (3), 
       (4), 
       (5);

INSERT INTO Category (CategoryName)
VALUES 
(N'Tiểu thuyết lịch sử'),
(N'Văn học cổ điển'),
(N'Tiểu thuyết hiện đại'),
(N'Sách tự học'),
(N'Sách dành cho thiếu nhi');


INSERT INTO Author (AuthorName, AuthorBio)
VALUES 
(N'Ngô Thì Nhậm', N'Ngô Thì Nhậm là một nhà văn Việt Nam nổi tiếng với các tác phẩm lịch sử.'),
(N'Nguyễn Du', N'Nguyễn Du là một nhà thơ nổi tiếng với tác phẩm Truyện Kiều.'),
(N'Nguyễn Nhật Ánh', N'Nguyễn Nhật Ánh là một nhà văn nổi tiếng với các tác phẩm dành cho thiếu nhi.'),
(N'Nguyễn Tuân', N'Nguyễn Tuân là một nhà văn nổi tiếng với các tác phẩm văn học cổ điển.'),
(N'Tạ Quang Bửu', N'Tạ Quang Bửu là một nhà văn nổi tiếng với các tác phẩm tiểu thuyết hiện đại.');





-- Sách của tác giả Lê Hồng Lâm
INSERT INTO Book (Title, AuthorID, Description, Price, Quantity, PublicationDate, CategoryID, Status)
VALUES 
(N'Những ngôi sao xa xôi', 1, N'Truyện kể về những câu chuyện tình yêu lãng mạn và đầy cảm xúc.', 35.99, 50, '1995-01-01', 1, 'Active'),
(N'Chí Phèo', 1, N'Truyện kể về cuộc đời của những người nông dân, với những khó khăn, gian truân và bi kịch.', 29.99, 40, '2000-01-01', 1, 'Active'),
(N'Lão Hạc', 1, N'Cuốn sách tập hợp những truyện ngắn về cuộc sống và tình yêu của người nông dân Việt Nam.', 25.99, 60, '2005-01-01', 1, 'Active');

-- Sách của tác giả Nguyễn Nhật Ánh
INSERT INTO Book (Title, AuthorID, Description, Price, Quantity, PublicationDate, CategoryID, Status)
VALUES 
(N'Kính vạn hoa', 2, N'Truyện kể về những kỷ niệm tuổi thơ đầy mơ mộng và tình bạn thân thiết.', 18.99, 70, '1993-01-01', 5, 'Active'),
(N'Trên đỉnh Phù Vân', 2, N'Truyện kể về cuộc phiêu lưu của nhóm bạn trẻ trên đỉnh núi Phù Vân.', 21.99, 80, '1997-01-01', 5, 'Active'),
(N'Cô gái đến từ hôm qua', 2, N'Cuốn sách kể về chuyến phiêu lưu trở lại tuổi thơ của một chàng trai.', 24.99, 90, '2001-01-01', 5, 'Active');

-- Sách của tác giả Nguyễn Đình Chiểu
INSERT INTO Book (Title, AuthorID, Description, Price, Quantity, PublicationDate, CategoryID, Status)
VALUES 
(N'Truyện Kiều Nam sự', 3, N'Bộ sách tập hợp những truyện lịch sử về nhân vật Kiều.', 39.99, 30, '1855-01-01', 1, 'Active'),
(N'Truyện Tây sự', 3, N'Những câu chuyện lịch sử về cuộc sống và tình yêu ở miền Tây Việt Nam.', 42.99, 35, '1860-01-01', 1, 'Active'),
(N'Thơ', 3, N'Bộ sưu tập những bài thơ nổi tiếng của Nguyễn Đình Chiểu.', 29.99, 25, '1843-01-01', 2, 'Active');

-- Sách của tác giả Nguyễn Du
INSERT INTO Book (Title, AuthorID, Description, Price, Quantity, PublicationDate, CategoryID, Status)
VALUES 
(N'Truyện Kiều', 4, N'Câu chuyện về cuộc đời của Kiều, một cô gái trẻ đầy tài năng và sắc đẹp.', 29.99, 100, '1815-01-01', 1, 'Active'),
(N'Phan Trọng Hương', 4, N'Những cuộc phiêu lưu và gian truân trong cuộc đời của nhân vật Phan Trọng Hương.', 25.99, 80, '1803-01-01', 1, 'Active'),
(N'Trinh Thử', 4, N'Những câu chuyện tình yêu và trách nhiệm của nhân vật Trinh Thử.', 24.99, 70, '1811-01-01', 1, 'Active');

-- Sách của tác giả Trí Nguyễn
INSERT INTO Book (Title, AuthorID, Description, Price, Quantity, PublicationDate, CategoryID, Status)
VALUES 
(N'Muốn biết bí mật của những người thành công', 5, N'Sách tập trung vào những bí mật và nguyên tắc của những người thành công.', 19.99, 120, '2010-01-01', 4, 'Active'),
(N'Bí mật tư duy triệu phú', 5, N'Sách chia sẻ về cách tư duy và hành động để trở thành một triệu phú.', 22.99, 130, '2012-01-01', 4, 'Active'),
(N'Bí mật của tư duy thành đạt', 5, N'Cung cấp các nguyên tắc và phương pháp tư duy để đạt được thành công trong cuộc sống.', 18.99, 110, '2015-01-01', 4, 'Active');
